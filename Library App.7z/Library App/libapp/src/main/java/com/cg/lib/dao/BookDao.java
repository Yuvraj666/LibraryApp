package com.cg.lib.dao;

import java.util.Collection;
import java.util.List;

import com.cg.lib.bean.Book;
import com.cg.lib.exception.LibException;

public interface BookDao {
	void addBook(Book book) throws LibException;

	void updateBook(Book book) throws LibException;

	void deleteBook(int bookCode) throws LibException;

	List<Book> getAllBooks();

	Book getBookById(int bookCode);

}
