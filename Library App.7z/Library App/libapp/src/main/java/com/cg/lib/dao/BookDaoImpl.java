package com.cg.lib.dao;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import com.cg.lib.bean.Book;
import com.cg.lib.exception.LibException;
import com.cg.lib.service.BookService;

public class BookDaoImpl implements BookDao {

	private Map<Integer, Book> booksMap;

	public BookDaoImpl() {
		booksMap = new TreeMap<>();
	}

	@Override
	public void addBook(Book book) throws LibException {
		if (book != null && !booksMap.containsKey(book.getBookCode())) {
			booksMap.put(book.getBookCode(), book);
		} else {
			throw new LibException("No Book or Duplicate Book received");
		}

	}

	@Override
	public void updateBook(Book book) throws LibException {
		if (book != null && booksMap.containsKey(book.getBookCode())) {
			booksMap.replace(book.getBookCode(), book);
		} else {
			throw new LibException("No book with the given key found");
		}

	}

	@Override
	public void deleteBook(int bookCode) throws LibException {
		if (booksMap.containsKey(bookCode)) {
			booksMap.remove(bookCode);
		} else {
			throw new LibException("No Book of given Book Code is present ");
		}
		// TODO Auto-generated method stub

	}

	@Override
	public List<Book> getAllBooks() {

		return new ArrayList<>(booksMap.values());
	}

	@Override
	public Book getBookById(int bookCode) {
		// TODO Auto-generated method stub
		return booksMap.get(bookCode);
	}

}
