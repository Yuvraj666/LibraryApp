package com.cg.lib.ui;

public class LibraryApp {
	public static void main(String[] args) {

		if (args.length > 0 ) {

			System.out.println("test case");
			System.out.println("production " + args[0]);
		} else {
			System.out.println("no cmd args");
			
		}

	}
}